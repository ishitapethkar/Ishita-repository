import java.util.ArrayList;

public class Stack<T> 
{
    
    private ArrayList<T> arr;
    private int top;
    
    public Stack()
    {
        this.arr = new ArrayList<T>();
        this.top = -1;
    }

    public boolean isEmpty()
    {
        return this.top == -1;
    }
    
    public void push(T elt)
    {
       this.arr.add(++top, elt);
    }

    public T pop()
    {
        if (isEmpty())
            return null;
        else
            return this.arr.remove(top--);
    }

    public T peek()
    {
        if (isEmpty())
            return null;
        else
            return this.arr.get(top);
    }
}




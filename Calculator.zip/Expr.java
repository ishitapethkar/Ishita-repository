 abstract public class Expr 
 {
	Expr subexp1;
	Expr subexp2;

	public Expr(Expr e1, Expr e2) 
    {
		subexp1 = e1;
		subexp2 = e2;
	}

    abstract String makeString();
	abstract public int evaluate();
}

class NumExpr extends Expr
{
    int n;

    public NumExpr(int num)
    {
        super(null,null);
        n = num;
    }

    public String makeString()
    {
        return "" + n;
    }

    public int evaluate()
    {
        return n;
    }
    
}


class AddExpr extends Expr
{
    public AddExpr(Expr e1,Expr e2)
    {
        super(e1,e2);
    }

    public String makeString()
    {
        return ("(" + this.subexp1.makeString() + " + " + this.subexp2.makeString() + ")");
    }

    public int evaluate()
    {
        return (this.subexp1.evaluate() + this.subexp2.evaluate());
    }
}

class SubExpr extends Expr 
{
    SubExpr(Expr e1,Expr e2)
    {
        super(e1,e2);
    }

    String makeString()
    {
        return("(" + this.subexp1.makeString() + " - " + this.subexp2.makeString() + ")");
        
    }

    public int evaluate()
    {
        return (this.subexp1.evaluate() - this.subexp2.evaluate());
    }
}

class MulExpr extends Expr 
{
    public MulExpr(Expr e1,Expr e2)
    {
        super(e1,e2);
    }

    public String makeString()
    {
        return("(" + this.subexp1.makeString() + " * " + this.subexp2.makeString() + ")");
        
    }

    public int evaluate()
    {
        return (this.subexp1.evaluate() * this.subexp2.evaluate());
    }
}

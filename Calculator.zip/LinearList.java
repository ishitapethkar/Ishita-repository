import java.util.ArrayList;

public class LinearList<T>
{
    private ArrayList<T> arr;
    private int size;

    public LinearList()
    {
        this.arr = new ArrayList<T>();
        this.size = -1;
    }

    private class Iter implements Iterator<T>
    {
        private int position;

        public Iter()
        {
            this.position = -1;
        }

        public boolean hasNext()
        {
            return this.position < LinearList.this.size;
        }
        
        public T next() 
        {
            if (this.hasNext())
            {
                return (LinearList.this.arr.get(++this.position));
            }
            else
            {
                return null;
            }
        }
    }

    public void add(T elem)
    {
        this.arr.add(++this.size,elem);
    }

    public Iter getIterator()
    { 
        return new Iter();
    }
}


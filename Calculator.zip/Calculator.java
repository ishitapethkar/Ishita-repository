public class Calculator {
	LinearList<Token> toklist;
	Stack<Expr> exprstack;
	
	public Calculator(LinearList<Token> toks) 
    {
		toklist = toks;		
		exprstack = new Stack<Expr>();
	}

    public Expr makeExpr() 
    {
        Iterator<Token> i = toklist.getIterator();
        while (i.hasNext())
        {
            i.next().hopOnStack(exprstack);
        }
        return(exprstack.pop());
    }
}
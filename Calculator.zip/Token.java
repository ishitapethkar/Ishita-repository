public class Token{
    public enum TokType {Num, Add, Sub, Mul}
	private TokType toktype;
	private int tokval;

    public Token(TokType typ) 
    {
        if (typ == TokType.Num )
        {
        }
        else
        {
            this.toktype = typ;
            this.tokval = 0;
        }  
    }

    public Token(TokType typ,int val)
    {
        if (typ == TokType.Num )
        {
            this.toktype = typ;
            this.tokval = val;
        }
        else
        {
        }  
    }

    public void hopOnStack(Stack<Expr> stack) 
    {
        Expr t1,t2;
        if (this.toktype == TokType.Num)
        {
            stack.push(new NumExpr(this.tokval));
        }
        else if (this.toktype == TokType.Add)
        {
            t1 = stack.pop();
            t2 = stack.pop();
            stack.push(new AddExpr(t2, t1));
        }
        else if (this.toktype == TokType.Sub)
        {
            t1 = stack.pop();
            t2 = stack.pop();
            stack.push(new SubExpr(t2,t1));
        }
        else if (this.toktype == TokType.Mul)
        {
            t1 = stack.pop();
            t2 = stack.pop();
            stack.push(new MulExpr(t2,t1));
        }
    }
}


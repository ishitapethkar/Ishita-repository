import java.util.ArrayList;
import java.util.Date;
import java.util.Dictionary;
import java.util.Hashtable;

public class DrivingFloor{
    public int cars;
    public int cof;
    public ArrayList<Integer> riderq;
    public ArrayList<Integer> carq;
    public Dictionary<Integer,Integer> rcpairs = new Hashtable();

    public DrivingFloor(int c){
        cars = c;
        cof = 0;
        riderq = new ArrayList<Integer>();
        carq = new ArrayList<Integer>();
        for (int i = 1; i < cars + 1; i++){ carq.add(i);}
    }

    public void takeAride(int rider_id, int ride_time){
        join(rider_id);
        enter(rider_id);
        sleeper(ride_time);
        leave(rider_id);
    }

    private synchronized void join(int rider_id){
        Date date;
        riderq.add(rider_id);
        date = new Date();
        System.out.println("Rider "+rider_id+" joins queue at "+date);
        System.out.println("Rider queue : "+riderq);
        System.out.println("Car queue : "+carq);
        System.out.println("Cars on floor: "+cof + "\n");
    }

    private synchronized void enter(int rider_id){
        while (cof == 5 || riderq.get(0) != rider_id){
            try{
                wait();
                }
                catch (InterruptedException e){}
            }
        rcpairs.put(riderq.get(0),carq.get(0));
        int rider = riderq.remove(0);
        int car = carq.remove(0);
        cof += 1;
        Date date;
        date = new Date();
        System.out.println("Rider "+rider+" starts ride in car "+car+" at "+date);
        System.out.println("Rider queue : "+riderq);
        System.out.println("Car queue : "+carq);
        System.out.println("Cars on floor: "+cof +"\n");
    }

    private void sleeper(int ride_time){
        try{
            Thread.sleep(ride_time);
        }
        catch(InterruptedException e){}
    }

    private synchronized void leave(int rider_id){
        int car = rcpairs.get(rider_id);
        carq.add(rcpairs.get(rider_id));
        cof -= 1;
        Date date;
        date = new Date();System.out.println("Rider " +rider_id+" finishes ride at "+date);
        System.out.println("Car " +car+ " joins queue at " +date);
        System.out.println("Rider queue : " +riderq);
        System.out.println("Car queue : " +carq);
        System.out.println("Cars on floor: "+cof + "\n");
        notifyAll();
    }
}